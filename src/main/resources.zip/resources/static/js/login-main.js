(function () {
    'use strict';

    var container = document.getElementById('toast-container');
    var password = document.getElementById('password');
    var form = document.getElementById('login-form');

    /* Administrador de Notificaciones Toast */
    function armToasts() {
        if (!container) return;
        container.querySelectorAll('.toast').forEach(function (t) {
            if (t.dataset.armed) return;
            t.dataset.armed = '1';
            setTimeout(function () { t.remove(); }, 5000);
        });
    }

    function toast(type, msg) {
        if (!container) return;
        container.innerHTML = '<div class="toast toast-' + type + '"' +
            (type === 'error' ? ' role="alert"' : '') + '>' + msg + '</div>';
        armToasts();
    }

    function resetPassword() {
        if (password) {
            password.value = '';
            password.focus();
        }
    }
    armToasts();

    /* Vista previa local (sin Spring Boot activo):
       Si el formulario conserva el atributo 'th:action', significa que la plantilla no fue procesada por Thymeleaf.
       Simula el login con credenciales 'admin' / 'admin' y valida campos vacíos localmente. */
    if (form && form.hasAttribute('th:action')) {
        container.innerHTML = '';
        if (location.search.indexOf('error') > -1) toast('error', 'Usuario o contraseña incorrectos');
        if (location.search.indexOf('logout') > -1) toast('success', 'Sesión cerrada correctamente');

        form.addEventListener('submit', function (e) {
            e.preventDefault();

            var usernameVal = form.username ? form.username.value.trim() : '';
            var passwordVal = form.password ? form.password.value.trim() : '';

            /* Validación personalizada mediante Notificaciones Toast */
            if (!usernameVal) {
                toast('error', 'Por favor ingresa tu usuario');
                if (form.username) form.username.focus();
                return;
            }

            if (!passwordVal) {
                toast('error', 'Por favor ingresa tu contraseña');
                if (form.password) form.password.focus();
                return;
            }

            /* Proceso de simulación de credenciales */
            var btn = form.querySelector('button[type=submit]');
            form.classList.add('htmx-request');
            if (btn) btn.disabled = true;

            setTimeout(function () {
                form.classList.remove('htmx-request');
                if (btn) btn.disabled = false;

                var ok = usernameVal === 'admin' && passwordVal === 'admin';
                if (ok) {
                    toast('success', 'Sesión iniciada correctamente (simulación local)');
                } else {
                    toast('error', 'Usuario o contraseña incorrectos');
                    resetPassword();
                }
            }, 700);
        });
    }

    /* Manejo de respuestas HTTP cuando Spring Boot y HTMX estén activos */
    document.body.addEventListener('htmx:beforeSwap', function (e) {
        if (e.detail.elt !== form) return;

        var xhr = e.detail.xhr;
        var url = xhr.responseURL || '';
        var isFullPage = /<html[\s>]/i.test(xhr.responseText || '');
        if (!isFullPage) return; // Si el backend devuelve un fragmento (ej. toast.html), swap normal

        e.detail.shouldSwap = false;
        if (url.indexOf('error') > -1) {
            toast('error', 'Usuario o contraseña incorrectos');
            resetPassword();
        } else if (url.indexOf('/login') === -1) {
            window.location.href = url; // Login exitoso: redirige al dashboard/inicio
        } else {
            window.location.reload();
        }
    });

    document.body.addEventListener('htmx:afterSwap', function (e) {
        if (e.target !== container) return;
        armToasts();
        if (container.querySelector('.toast-error')) resetPassword();
    });

    document.body.addEventListener('htmx:responseError', function (e) {
        var status = e.detail.xhr.status;
        toast('error', status === 403
            ? 'La sesión expiró. Recarga la página e inténtalo de nuevo.'
            : 'Error del servidor (' + status + '). Intenta de nuevo.');
    });

    document.body.addEventListener('htmx:sendError', function () {
        toast('error', 'No se pudo conectar con el servidor. Intenta de nuevo.');
    });
})();