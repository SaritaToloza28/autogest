/* ==========================================================

Autogest · Escena 3D del login

Three.js r128 + GLTFLoader (cargados desde CDN en login.html)



Qué hace:

1. Carga el modelo /models/car/scene.gltf

2. Lo escala y lo centra automáticamente (bounding box)

3. Lo ubica en la mitad derecha de la pantalla (en móvil, arriba)

4. Lo hace girar sin parar sobre el eje Y

========================================================== */

(function () {

'use strict';



window.AUTOGEST_3D = true; // le avisa a login.html que este archivo sí cargó



var canvas = document.getElementById('bg-canvas');

var statusEl = document.getElementById('scene-status');



/* Mensaje visible sobre la zona del carro (útil para depurar sin abrir F12) */

function setStatus(text, isError) {

console[isError ? 'warn' : 'info']('[Autogest] ' + text);

if (!statusEl) return;

statusEl.textContent = text;

statusEl.classList.toggle('is-error', !!isError);

statusEl.classList.remove('is-hidden');

}



if (!canvas) return;

if (typeof THREE === 'undefined') {

setStatus('No cargó Three.js desde la CDN. ¿Hay conexión a internet?', true);

return;

}

if (!THREE.GLTFLoader) {

setStatus('No cargó GLTFLoader desde la CDN. ¿Hay conexión a internet?', true);

return;

}

if (location.protocol === 'file:') {

setStatus('Abriste el archivo con doble clic (file://). Ábrelo desde un servidor local.', true);

return;

}



/* ---------- Configuración (fácil de ajustar) ---------- */

var CONFIG = {

modelUrl: canvas.dataset.car || '/models/car/scene.gltf',

carLength: 4.5, // largo del carro en unidades de la escena

rotationSpeed: 0.45, // radianes por segundo (≈ 1 vuelta cada 14 s)

fov: 35, // apertura de la cámara en grados

cameraTilt: 0.28 // inclinación de la cámara hacia abajo (radianes ≈ 16°)

};



/* El .gltf pide una textura con otro nombre al que trae la carpeta textures/.

En lugar de editar el .gltf, se redirige la petición al archivo real. */

var TEXTURE_ALIAS = {

'kia_sportage_mat_0_baseColor.png': 'kia.png'

};



var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;



/* ---------- Renderer ---------- */

var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true });

renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

renderer.outputEncoding = THREE.sRGBEncoding; // colores correctos de las texturas

renderer.toneMapping = THREE.ACESFilmicToneMapping; // tono "cinematográfico" realista

renderer.toneMappingExposure = 1.05;

renderer.shadowMap.enabled = true;

renderer.shadowMap.type = THREE.PCFSoftShadowMap;



/* ---------- Escena y cámara ---------- */

var scene = new THREE.Scene(); // fondo transparente: se ve el CSS

var camera = new THREE.PerspectiveCamera(CONFIG.fov, 1, 0.1, 100);



/* ---------- Iluminación ---------- */

var ambient = new THREE.AmbientLight(0xffffff, 0.35); // luz suave general

scene.add(ambient);



var keyLight = new THREE.DirectionalLight(0xffffff, 1.6); // luz principal (proyecta sombra)

keyLight.position.set(5, 8, 6);

keyLight.castShadow = true;

keyLight.shadow.mapSize.set(1024, 1024);

keyLight.shadow.camera.left = -5;

keyLight.shadow.camera.right = 5;

keyLight.shadow.camera.top = 5;

keyLight.shadow.camera.bottom = -5;

keyLight.shadow.radius = 4;

keyLight.shadow.bias = -0.0005;

scene.add(keyLight);



var fillLight = new THREE.DirectionalLight(0xe9ddff, 0.6); // relleno lavanda desde atrás

fillLight.position.set(-6, 3, -5);

scene.add(fillLight);



/* ---------- Reflejos: mini "estudio fotográfico" ----------

Los materiales PBR del modelo necesitan algo que reflejar.

Se crea una caja con paneles blancos y se convierte en mapa de entorno. */

function createStudioEnvironment() {

var pmrem = new THREE.PMREMGenerator(renderer);

var studio = new THREE.Scene();



studio.add(new THREE.Mesh(

new THREE.BoxGeometry(30, 15, 30),

new THREE.MeshBasicMaterial({ color: 0xb9a9d6, side: THREE.BackSide })

));



function softbox(w, h, x, y, z, intensity) {

var panel = new THREE.Mesh(

new THREE.PlaneGeometry(w, h),

new THREE.MeshBasicMaterial({

color: new THREE.Color(0xffffff).multiplyScalar(intensity),

side: THREE.DoubleSide

})

);

panel.position.set(x, y, z);

panel.lookAt(0, 0, 0);

studio.add(panel);

}

softbox(12, 6, 0, 7, 0, 4); // techo

softbox(4, 8, -12, 3, 4, 3); // lateral izquierdo

softbox(4, 8, 12, 3, -4, 3); // lateral derecho



var envMap = pmrem.fromScene(studio, 0.04).texture;

pmrem.dispose();

return envMap;

}

scene.environment = createStudioEnvironment();



/* ---------- Piso invisible que solo recibe la sombra ---------- */

var floor = new THREE.Mesh(

new THREE.PlaneGeometry(30, 30),

new THREE.ShadowMaterial({ color: 0x170933, opacity: 0.18 })

);

floor.rotation.x = -Math.PI / 2;

floor.receiveShadow = true;

scene.add(floor);



/* ---------- Carga del modelo ---------- */

var manager = new THREE.LoadingManager();

manager.setURLModifier(function (url) {

for (var original in TEXTURE_ALIAS) {

if (url.indexOf(original) !== -1) return url.replace(original, TEXTURE_ALIAS[original]);

}

return url;

});



var car = new THREE.Group(); // pivote: se gira este grupo, no el modelo

var carSize = new THREE.Vector3(CONFIG.carLength, 1.6, 2);

scene.add(car);



new THREE.GLTFLoader(manager).load(

CONFIG.modelUrl,

function (gltf) {

var model = gltf.scene;



model.traverse(function (obj) {

if (!obj.isMesh) return;

obj.castShadow = true;

obj.receiveShadow = true;

if (obj.material) obj.material.envMapIntensity = 1.0;

});



/* 1) Escalar: el lado más largo (largo del carro) mide CONFIG.carLength */

var box = new THREE.Box3().setFromObject(model);

var size = box.getSize(new THREE.Vector3());

model.scale.setScalar(CONFIG.carLength / Math.max(size.x, size.z));



/* 2) Centrar en X/Z y apoyar las ruedas en el piso (y = 0) */

box.setFromObject(model);

var center = box.getCenter(new THREE.Vector3());

model.position.set(-center.x, -box.min.y, -center.z);



box.setFromObject(model);

box.getSize(carSize);



car.add(model);

car.rotation.y = -0.6; // pose inicial en tres cuartos

layout();

document.body.classList.add('scene-ready'); // el CSS hace el fade-in del canvas

if (statusEl) statusEl.classList.add('is-hidden');

if (reduceMotion) render();

},

undefined,

function (error) {

console.error(error);

setStatus('No se pudo cargar el modelo: ' + new URL(CONFIG.modelUrl, location.href).pathname +

' — revisa que exista scene.gltf, scene.bin y textures/kia.png en esa carpeta.', true);

}

);



/* Errores al descargar .bin o texturas (el .gltf puede cargar y ellos no) */

manager.onError = function (url) {

setStatus('Falta un archivo del modelo: ' + new URL(url, location.href).pathname, true);

};



/* ---------- Encuadre responsive ----------

La cámara siempre apunta al centro del carro. Con setViewOffset se

"desplaza" la imagen para que el carro quede en la mitad derecha

(escritorio) o en la parte superior (móvil), sin deformar la perspectiva. */

function layout() {

var w = window.innerWidth;

var h = window.innerHeight;

var aspect = w / h;

var tanHalf = Math.tan(THREE.MathUtils.degToRad(CONFIG.fov / 2));



// Al girar, el carro ocupa como máximo la diagonal de su planta

var spin = Math.sqrt(carSize.x * carSize.x + carSize.z * carSize.z);

var tall = carSize.y + spin * 0.35; // alto aparente visto desde arriba

var desktop = w > 900;

var distance;



if (desktop) {

// El carro debe caber en ~45 % del ancho y ~55 % del alto

distance = Math.max(spin / (0.45 * 2 * tanHalf * aspect), tall / (0.55 * 2 * tanHalf));

} else {

// En móvil: ~85 % del ancho y ~32 % del alto (la tarjeta va abajo)

distance = Math.max(spin / (0.85 * 2 * tanHalf * aspect), tall / (0.32 * 2 * tanHalf));

}



var target = new THREE.Vector3(0, carSize.y * 0.45, 0);

camera.position.set(

0,

target.y + Math.sin(CONFIG.cameraTilt) * distance,

Math.cos(CONFIG.cameraTilt) * distance

);

camera.lookAt(target);

camera.aspect = aspect;



if (desktop) {

camera.setViewOffset(w, h, -w * 0.24, 0, w, h); // centro del carro ≈ 74 % del ancho

} else {

camera.setViewOffset(w, h, 0, h * 0.27, w, h); // centro del carro ≈ 23 % del alto

}

camera.updateProjectionMatrix();

renderer.setSize(w, h, false);

}



function render() {

renderer.render(scene, camera);

}



window.addEventListener('resize', function () {

layout();

if (reduceMotion) render();

});

layout();



/* ---------- Bucle de animación: giro continuo en Y ---------- */

if (reduceMotion) return; // accesibilidad: el usuario pidió menos movimiento



var clock = new THREE.Clock();

function animate() {

requestAnimationFrame(animate);

var delta = Math.min(clock.getDelta(), 0.1); // evita saltos al volver a la pestaña

car.rotation.y += CONFIG.rotationSpeed * delta;

render();

}

animate();

})();
